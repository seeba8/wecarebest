/**
 * Created by sebas on 19/05/2016.
 */
var mongo = {
    username: "wecarebest",
    password: "wirsinddiebesten2016",
    url: "ds025752.mlab.com:25752/wecarebest"
};
module.exports = mongo;