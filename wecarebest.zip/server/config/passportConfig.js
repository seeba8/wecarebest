/**
 * Created by Layla M on 29.05.2016.
 */


module.exports = {'secret': 'wecarebest'}
